
# Wajid AI — Swing Forecast page

Files:
- api/forecast.js -> copy to your repo's api/forecast.js
- forecast.html -> copy to your repo root

Then add this link to the strategy navigation in index.html (and optionally liquidity.html):
<a href="/forecast.html" class="strategy-link"><span class="strategy-icon">📐</span> Swing Forecast</a>

Logic:
1. The newest candle is treated as the currently forming/next entry candle.
2. Signal calculation uses only candles before the newest candle.
3. A signal is created only when the latest completed candle confirms a new swing direction.
4. Entry is the newest candle's OPEN.
5. Forecast target is kept separate from TP1/TP2 because the Pine forecast target is projected from the swing origin, not necessarily from the trade entry.
6. No changes are made to the existing Strong SD Magnet or Swing Liquidity engines.
